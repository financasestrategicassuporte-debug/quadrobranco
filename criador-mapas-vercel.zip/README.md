# Criador de Mapas Mentais: Vercel + Supabase

```
index.html                 ← o app (precisa ficar na RAIZ do projeto)
api/mapas/index.js         ← GET    /api/mapas
api/mapas/[id].js          ← GET/PUT/DELETE /api/mapas/:id
api/mapas/gerar.js         ← POST   /api/mapas/gerar  (IA)
lib/core.js, lib/gerador.js
supabase/schema.sql        ← tabelas do banco
vercel.json, package.json
test/api.test.js           ← node test/api.test.js
```

## Passo a passo

### 1. Banco no Supabase
1. Supabase → seu projeto → **SQL Editor** → **New query**.
2. Paste the contents of `supabase/schema.sql`. Before running, change the name and email on the last line.
3. Click **Run**. The result shows the **api_token**: copy it.

### 2. Chaves
- Supabase → **Project Settings → API**. Copy the **Project URL** and the **service_role** key (or the new **secret** key, `sb_secret_...`).
- Anthropic Console → **API Keys** → crie uma chave.

### 3. Projeto na Vercel
1. Put **the files from this folder** (not the folder itself) at the root of a GitHub repository, then import it into Vercel.
   *(Or: in the terminal, inside this folder, run `npx vercel`.)*
2. Em **Settings → Build and Deployment**:
   - **Framework Preset:** Other
   - **Root Directory:** leave it empty (`./`), unless the files are in a subfolder of the repo.
   - **Build Command** e **Output Directory:** vazios.
3. Em **Settings → Environment Variables**, crie:

| Variável | Valor |
|---|---|
| `SUPABASE_URL` | `https://xxxx.supabase.co` |
| `SUPABASE_SERVICE_ROLE_KEY` | chave service_role / secret |
| `ANTHROPIC_API_KEY` | `sk-ant-...` |
| `ANTHROPIC_MODEL` | (opcional) padrão `claude-sonnet-5-5` |

4. **Redeploy** (environment variables only take effect on a new deploy).

### 4. Usar
Abra `https://SEU-PROJETO.vercel.app/?token=SEU_API_TOKEN` uma vez.
The token is saved in the browser and removed from the URL. Under "Meus mapas" you should see the message *"Seus mapas ficam salvos neste canvas e abrem em qualquer dispositivo"*.

Para criar mais usuários, rode no SQL Editor:
```sql
insert into public.usuarios (nome, email) values ('Nome', 'email@gfb.com.br') returning api_token;
```

## Se der erro

| Sintoma | Causa provável |
|---|---|
| 404 NOT_FOUND em `/` | `index.html` is not at the project root (check the Root Directory) |
| App abre, mas diz "salvos neste navegador" | Missing `?token=`, wrong token, or variables not set (redeploy after setting them) |
| `/api/mapas` returns `{"error":"not_configured"}` | Missing `SUPABASE_*` or `ANTHROPIC_API_KEY` |
| `/api/mapas` returns `{"error":"db_error"}` | `schema.sql` wasn't run, or the key isn't the secret/service_role key |
| IA demora e falha | Very long text. AI generation is capped at 60s (`vercel.json`). With Fluid compute, you can raise it up to 300 |

Para ver o erro detalhado: Vercel → projeto → **Logs**.
