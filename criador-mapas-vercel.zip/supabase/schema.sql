-- Rode no Supabase: SQL Editor > New query > cole tudo > Run.

create table if not exists public.usuarios (
  id bigint generated always as identity primary key,
  nome text not null,
  email text not null unique,
  api_token text not null unique
    default replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', ''),
  created_at timestamptz not null default now()
);

create table if not exists public.mapas (
  id bigint generated always as identity primary key,
  usuario_id bigint not null references public.usuarios(id) on delete cascade,
  client_id text not null check (client_id ~ '^[A-Za-z0-9_-]{1,64}$'),  -- id gerado no navegador
  title text not null default 'Sem título',
  data jsonb not null default '{}'::jsonb,                             -- o mapa inteiro
  client_updated_at bigint not null,                                   -- updatedAt do navegador (ms)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (usuario_id, client_id)
);
create index if not exists mapas_usuario_recentes on public.mapas (usuario_id, client_updated_at desc);

-- Usado para limitar a IA a 10 gerações por minuto por usuário.
create table if not exists public.geracoes (
  id bigint generated always as identity primary key,
  usuario_id bigint not null references public.usuarios(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists geracoes_usuario_tempo on public.geracoes (usuario_id, created_at);

-- RLS ligado e sem políticas: a chave pública (anon) não acessa nada.
-- Só as funções da Vercel, com a chave secreta, leem e gravam.
alter table public.usuarios enable row level security;
alter table public.mapas enable row level security;
alter table public.geracoes enable row level security;

-- Criar um usuário (rode quantas vezes precisar, trocando nome e e-mail).
-- O resultado mostra o token de acesso.
insert into public.usuarios (nome, email)
values ('Kauam', 'kauam@gfb.com.br')
returning api_token;
