// Testes sem dependências: node test/api.test.js
// Roda as funções de /api com um Supabase (PostgREST) e uma Claude API falsos.
'use strict';
const assert = require('assert');
const path = require('path');

process.env.SUPABASE_URL = 'https://fake.supabase.co';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'sb_secret_teste';
process.env.ANTHROPIC_API_KEY = 'sk-ant-teste';

// ---------- Supabase falso: só o que as funções usam ----------
const db = { usuarios: [], mapas: [], geracoes: [] };
let seq = 1;
let claudeReply = '{"title":"Mapa","nodes":[{"label":"A","children":[{"label":"B"}]}]}';
let claudeStatus = 200;
const seen = [];

function matches(row, filters) {
  return filters.every(([col, op, val]) => {
    const v = row[col];
    if (op === 'eq') return String(v) === val;
    if (op === 'gte') return String(v) >= val;
    throw new Error('op não suportada ' + op);
  });
}

global.fetch = async (url, opt = {}) => {
  const res = (status, body) => ({ status, ok: status < 300, text: async () => (body == null ? '' : JSON.stringify(body)) });
  if (url.startsWith('https://api.anthropic.com')) {
    seen.push({ claude: JSON.parse(opt.body), headers: opt.headers });
    if (claudeStatus !== 200) return res(claudeStatus, { error: 'x' });
    return res(200, { content: [{ type: 'text', text: claudeReply }], stop_reason: 'end_turn' });
  }
  assert.ok(url.startsWith('https://fake.supabase.co/rest/v1/'), url);
  assert.equal(opt.headers.apikey, 'sb_secret_teste');
  assert.equal(opt.headers.Authorization, undefined, 'chave sb_secret não vai no Authorization');
  const u = new URL(url);
  const table = u.pathname.replace('/rest/v1/', '');
  const filters = []; let select = null; let order = null; let limit = Infinity; let onConflict = null;
  for (const [k, v] of u.searchParams) {
    if (k === 'select') select = v.split(',');
    else if (k === 'order') order = v.split('.');
    else if (k === 'limit') limit = Number(v);
    else if (k === 'on_conflict') onConflict = v.split(',');
    else { const i = v.indexOf('.'); filters.push([k, v.slice(0, i), v.slice(i + 1)]); }
  }
  const rows = db[table];
  const method = opt.method || 'GET';
  if (method === 'GET') {
    let out = rows.filter(r => matches(r, filters));
    if (order) out.sort((a, b) => (order[1] === 'desc' ? -1 : 1) * (a[order[0]] > b[order[0]] ? 1 : -1));
    out = out.slice(0, limit).map(r => (select ? Object.fromEntries(select.map(c => [c, r[c]])) : r));
    return res(200, JSON.parse(JSON.stringify(out)));
  }
  if (method === 'POST') {
    const body = JSON.parse(opt.body);
    const ex = onConflict && rows.find(r => onConflict.every(c => r[c] === body[c]));
    if (ex) Object.assign(ex, body); else rows.push(Object.assign({ id: seq++, created_at: new Date().toISOString() }, body));
    return res(201, null);
  }
  if (method === 'DELETE') {
    db[table] = rows.filter(r => !matches(r, filters));
    return res(204, null);
  }
  throw new Error('método ' + method);
};

// ---------- req/res no formato das funções Node da Vercel ----------
function call(file, { method = 'GET', token, query = {}, body } = {}) {
  const fn = require(path.join(__dirname, '..', 'api', 'mapas', file));
  return new Promise((resolve, reject) => {
    const res = {
      statusCode: 200, headers: {},
      setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
      end(data) { resolve({ status: this.statusCode, body: data ? JSON.parse(data) : null }); }
    };
    const req = { method, query, body, headers: token ? { authorization: 'Bearer ' + token } : {} };
    fn(req, res).catch(reject);
  });
}

const T1 = 'a'.repeat(64), T2 = 'b'.repeat(64);
db.usuarios.push({ id: 1, nome: 'Kauam', email: 'k@x', api_token: T1 }, { id: 2, nome: 'Outro', email: 'o@x', api_token: T2 });
const mapa = (t) => JSON.stringify({ id: 'm1', title: t, layout: 'mapa', nodes: [{ id: 'r', parent: null, label: t, x: 0, y: 0 }] });

(async () => {
  // autenticação
  assert.equal((await call('index.js')).status, 401);
  assert.equal((await call('index.js', { token: 'c'.repeat(64) })).status, 401);
  assert.equal((await call('index.js', { token: 'x;drop' })).status, 401);
  assert.equal((await call('index.js', { token: T1, method: 'POST' })).status, 405);

  // cria, atualiza, lista, abre
  let r = await call('[id].js', { method: 'PUT', token: T1, query: { id: 'm1' }, body: { title: 'Funil', updatedAt: 1000, data: mapa('Funil') } });
  assert.deepEqual(r, { status: 200, body: { id: 'm1', title: 'Funil', updatedAt: 1000 } });
  r = await call('[id].js', { method: 'PUT', token: T1, query: { id: 'm1' }, body: { title: 'Funil 2', updatedAt: 2000, data: mapa('Funil 2') } });
  assert.equal(db.mapas.length, 1, 'upsert não duplica');
  await call('[id].js', { method: 'PUT', token: T1, query: { id: 'm2' }, body: { title: 'Outro mapa', updatedAt: 1500, data: mapa('Outro') } });
  r = await call('index.js', { token: T1 });
  assert.deepEqual(r.body, [{ id: 'm1', title: 'Funil 2', updatedAt: 2000 }, { id: 'm2', title: 'Outro mapa', updatedAt: 1500 }]);
  r = await call('[id].js', { token: T1, query: { id: 'm1' } });
  assert.equal(JSON.parse(r.body.data).title, 'Funil 2');

  // isolamento entre usuários
  assert.deepEqual((await call('index.js', { token: T2 })).body, []);
  assert.equal((await call('[id].js', { token: T2, query: { id: 'm1' } })).status, 404);

  // validações
  assert.equal((await call('[id].js', { method: 'PUT', token: T1, query: { id: 'm1' }, body: { data: '{"x":1}' } })).status, 422);
  assert.equal((await call('[id].js', { method: 'PUT', token: T1, query: { id: 'm1' }, body: { data: 'nada' } })).status, 422);
  assert.equal((await call('[id].js', { token: T1, query: { id: 'a.b&x=1' } })).status, 400);

  // exclusão (só do próprio usuário)
  await call('[id].js', { method: 'DELETE', token: T2, query: { id: 'm2' } });
  assert.equal(db.mapas.length, 2);
  assert.equal((await call('[id].js', { method: 'DELETE', token: T1, query: { id: 'm2' } })).status, 204);
  assert.equal(db.mapas.length, 1);

  // IA
  r = await call('gerar.js', { method: 'POST', token: T1, body: { text: 'WEBVTT\n\n1\n00:00 --> 00:01\nReunião do funil', focus: 'reuniao' } });
  assert.deepEqual(r.body, { title: 'Mapa', nodes: [{ label: 'A', note: '', children: [{ label: 'B', note: '', children: [] }] }] });
  const sent = seen[seen.length - 1];
  assert.equal(sent.claude.model, 'claude-sonnet-5-5');
  assert.ok(sent.claude.system.includes('RESUMIR UMA REUNIÃO'));
  assert.ok(sent.claude.messages[0].content.includes('Reunião do funil'));
  assert.ok(!sent.claude.messages[0].content.includes('-->'));
  assert.equal(sent.claude.temperature, undefined);
  assert.equal(sent.headers['x-api-key'], 'sk-ant-teste');

  claudeReply = '```json\n{"title":"X","nodes":[{"label":"Só um"}]}\n```';
  r = await call('gerar.js', { method: 'POST', token: T1, body: { text: 'oi', focus: 'invalido' } });
  assert.equal(r.body.nodes[0].label, 'Só um');
  assert.ok(seen[seen.length - 1].claude.system.includes('MAPEAR UM PROCESSO'));

  claudeReply = 'não sei';
  assert.deepEqual(await call('gerar.js', { method: 'POST', token: T1, body: { text: 'oi' } }), { status: 502, body: { error: 'empty' } });
  assert.equal((await call('gerar.js', { method: 'POST', token: T1, body: { text: '  ' } })).status, 422);

  claudeStatus = 429;
  assert.deepEqual(await call('gerar.js', { method: 'POST', token: T1, body: { text: 'oi' } }), { status: 429, body: { error: 'rate_limited' } });
  claudeStatus = 200; claudeReply = '{"title":"X","nodes":[{"label":"A"}]}';

  // limite de 10 por minuto (4 chamadas já registradas acima)
  for (let i = 0; i < 6; i++) assert.equal((await call('gerar.js', { method: 'POST', token: T1, body: { text: 'oi' } })).status, 200);
  assert.deepEqual(await call('gerar.js', { method: 'POST', token: T1, body: { text: 'oi' } }), { status: 429, body: { error: 'rate_limited' } });
  assert.equal((await call('gerar.js', { method: 'POST', token: T2, body: { text: 'oi' } })).status, 200, 'limite é por usuário');

  // sem configuração
  delete process.env.ANTHROPIC_API_KEY;
  assert.deepEqual(await call('gerar.js', { method: 'POST', token: T2, body: { text: 'oi' } }), { status: 500, body: { error: 'not_configured' } });

  console.log('Todos os testes passaram');
})().catch(e => { console.error(e); process.exit(1); });
